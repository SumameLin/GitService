#include "@WIDGET_HEADER@"

@WIDGET_CLASS@::@WIDGET_CLASS@(QWidget *parent) :
    @WIDGET_BASE_CLASS@(parent)
{
}
