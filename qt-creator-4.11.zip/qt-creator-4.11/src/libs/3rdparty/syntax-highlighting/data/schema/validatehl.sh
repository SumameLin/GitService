#!/bin/sh
xmllint --noout --schema language.xsd $@ 
