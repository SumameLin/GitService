<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="15"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="main.qml" line="29"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>PushButton</source>
        <translation>PushButton</translation>
    </message>
    <message>
        <location filename="main.qml" line="45"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main.qml" line="49"/>
        <source>简体中文</source>
        <translation></translation>
    </message>
</context>
</TS>
