<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="15"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="main.qml" line="29"/>
        <source>TextLabel</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>PushButton</source>
        <translation>按钮</translation>
    </message>
    <message>
        <location filename="main.qml" line="45"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main.qml" line="49"/>
        <source>简体中文</source>
        <translation></translation>
    </message>
</context>
</TS>
