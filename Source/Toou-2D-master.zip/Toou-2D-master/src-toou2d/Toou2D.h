#ifndef TOOU2D_H
#define TOOU2D_H

#include <QQmlEngine>

class Toou2D
{
public:
    static void create(QQmlEngine* engine);
    static QString version();
};

#endif // TOOU2D_H
