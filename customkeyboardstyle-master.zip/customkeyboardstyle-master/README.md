# customkeyboardstyle
qml custom keyboard style

参考Qt文档，自定义Qt Virtual Keyboard样式

官方参考文档：https://doc.qt.io/archives/qt-5.11/technical-guide.html#keyboard-styles

该项目参考：https://blog.csdn.net/eiilpux17/article/details/108175856
