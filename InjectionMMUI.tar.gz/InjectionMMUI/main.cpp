﻿#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <ConsoleAppender.h>
#include <QFont>
#include <Logger.h>
#include <QQmlContext>
#include "./Libaries/SetLanguage/SetLanguage.h"
#include "./Libaries/ScreenShot/ScreenShot.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);
    //字体
    QFont font;
    font.setFamily("qrc:/Font/SourceHanRegular.ttf");
    app.setFont(font);
    //注册ConsoleAppender 到 CuteLogger
    ConsoleAppender* consoleAppender = new ConsoleAppender;
    consoleAppender->setFormat("[%{type:-7}] <%{Function}> %{message}\n");
    cuteLogger->registerAppender(consoleAppender);
    LOG_INFO("Starting the InjectionSystem!");

    QQmlApplicationEngine engine;
    //"language"必须小写字母开头，QML才能访问C++对象的函数与属性
    SetLanguage language(app, engine);
    engine.rootContext()->setContextProperty("language",&language);
    //ScreenShot注册到QML中
    ScreenShot screenshot;
    engine.rootContext()->setContextProperty("screenshot", &screenshot);
    //设置SQLite数据库存储路径,LocalStorage访问SQLite数据库
    //engine.setOfflineStoragePath("./SQLiteDB");
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
