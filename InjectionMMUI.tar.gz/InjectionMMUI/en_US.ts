<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>AdminPage</name>
    <message>
        <location filename="QML/MenuPage/AdminPage.qml" line="7"/>
        <source>管理员</source>
        <translation>Admin</translation>
    </message>
</context>
<context>
    <name>BottomTabBar</name>
    <message>
        <location filename="QML/BottomTabBar.qml" line="25"/>
        <source>主界面</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="33"/>
        <source>注射</source>
        <translation>Inject</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="41"/>
        <source>开关模</source>
        <translation>Open</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="49"/>
        <source>温度</source>
        <translation>Temp</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="57"/>
        <source>快速设置</source>
        <translation>Setting</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="65"/>
        <source>生产</source>
        <translation>Produce</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="73"/>
        <source>维护</source>
        <translation>Maintain</translation>
    </message>
    <message>
        <location filename="QML/BottomTabBar.qml" line="81"/>
        <source>警告</source>
        <translation>Waring</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="QML/MenuPage/HomePage.qml" line="7"/>
        <source>主界面</source>
        <translation>Home</translation>
    </message>
</context>
<context>
    <name>InjectPage</name>
    <message>
        <location filename="QML/MenuPage/InjectPage.qml" line="16"/>
        <source>增加按钮</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QML/MenuPage/InjectPage.qml" line="29"/>
        <source>删除按钮</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MaintainPage</name>
    <message>
        <location filename="QML/MenuPage/MaintainPage.qml" line="7"/>
        <source>维护</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>OpenPage</name>
    <message>
        <location filename="QML/MenuPage/OpenPage.qml" line="7"/>
        <source>开关模</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ProducePage</name>
    <message>
        <location filename="QML/MenuPage/ProducePage.qml" line="7"/>
        <source>生产</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SettingPage</name>
    <message>
        <location filename="QML/MenuPage/SettingPage.qml" line="7"/>
        <source>快速设置</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>TemperPage</name>
    <message>
        <location filename="QML/MenuPage/TemperPage.qml" line="7"/>
        <source>温度</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>TopStatusBar</name>
    <message>
        <location filename="QML/TopStatusBar.qml" line="48"/>
        <source>自动运行</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WaringPage</name>
    <message>
        <location filename="QML/MenuPage/WaringPage.qml" line="7"/>
        <source>警告</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>dataloader</name>
    <message>
        <location filename="QML/JavaScript/dataloader.js" line="3"/>
        <source>设置参数</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="23"/>
        <source>InjectionMM</source>
        <translation></translation>
    </message>
</context>
</TS>
