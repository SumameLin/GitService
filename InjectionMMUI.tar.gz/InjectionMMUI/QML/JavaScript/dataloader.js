﻿WorkerScript.onMessage = function(msg) {
    if (msg.action === 'appendNewBotton') {
        var data = {modelText: QT_TR_NOOP("设置参数"),
                    modelColor: "#000000", modelColorSelect: "#148014",
                    modelImage: "qrc:/Resource/BottomMenuSvg/admin.svg",
                    modelImageSelect: "qrc:/Resource/BottomMenuSvg/adminSelect.svg"};
        msg.model.append(data);
        msg.model.sync();   // updates the changes to the list
    }
    if (msg.action === 'removeNewBotton'){
        msg.model.remove(8);
        msg.model.sync();
    }
}
