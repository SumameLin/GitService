﻿#ifndef __SCREENSHOT_H
#define __SCREENSHOT_H

#include <QImage>
#include <QSharedPointer>
#include <QQuickItem>
#include <QQuickItemGrabResult>
#include <QQuickWindow>

class ScreenShot : public QObject
{
    Q_OBJECT
public:
    explicit ScreenShot(QObject *parent = nullptr);
    //截图控件
    Q_INVOKABLE void shootScreenControl(QObject *itemObj);
    //截图窗口
    Q_INVOKABLE void shootScreenWindow(QQuickWindow *rootWindow);

private slots:
    void saveImage();

private:
    QQuickItem *grabItem;
    QSharedPointer<QQuickItemGrabResult> grabResult;
};


#endif //__SCREENSHOT_H
