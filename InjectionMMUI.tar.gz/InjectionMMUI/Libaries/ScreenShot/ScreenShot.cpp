﻿#include "ScreenShot.h"
#include <Logger.h>
#include <QDateTime>

//构造函数后加冒号是初始化表达式
ScreenShot::ScreenShot(QObject *parent) : QObject(parent)
{

}

void ScreenShot::shootScreenControl(QObject *itemObj)
{
    //函数模板通过<>里的参数进行实例化
    //qobject_cast()动态转换QObject类的类型
    grabItem = qobject_cast<QQuickItem*>(itemObj);
    grabResult = grabItem->grabToImage();

    QQuickItemGrabResult *grabResultData = grabResult.data();
    connect(grabResultData,SIGNAL(ready()),this,SLOT(saveImage()));
}

void ScreenShot::shootScreenWindow(QQuickWindow *rootWindow)
{
    QImage image = rootWindow->grabWindow();
    QString filePathName = "./myScreenShot/";
    filePathName += QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss-zzz");
    filePathName += QString(".jpg");

    if(image.save(filePathName,"JPG")){
        LOG_INFO("save window sucessfully!");
    }
    else{
        LOG_INFO("save window failed!");
    }
}

void ScreenShot::saveImage()
{
    QString filePathName = "./myScreenShot/";
    filePathName += QDateTime::currentDateTime().toString("yyyy-MM-dd hh-mm-ss-zzz");
    filePathName += QString(".jpg");
    QImage img = grabResult->image();
    if(img.save(filePathName)){
        LOG_INFO("save control sucessfully!");
    }
    else{
        LOG_INFO("save control failed!");
    }
}
