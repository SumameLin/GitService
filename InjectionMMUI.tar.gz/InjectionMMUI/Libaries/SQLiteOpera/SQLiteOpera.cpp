﻿/******************************************************************************
 * Copyright 2020-2050 INOVANCE Co., Ltd. All right reserved.
 *
 * @file       SQLiteOpera.cpp
 * @brief      SQLite操作函数，注册到QML中
 *
 * @date       2021/07/31
 * @author     linrui
 * @history
 *****************************************************************************/
#include "SQLiteOpera.h"
#include <Logger.h>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

SQLiteOpera::SQLiteOpera(QObject *parent) : QObject(parent)
{

}

SQLiteOpera::~SQLiteOpera()
{

}

//查询用户密码
QString SQLiteOpera::queryPassword(QString usrName)
{
    QString password;
    //连接数据库
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    //如果没有会自动创建
    db.setDatabaseName(SQLiteDBPath);
    if(db.open()){
        LOG_ERROR("AllDataDB is missing!!!");
        //TODO：状态处理，必须要有数据库，否则报错
    }
    QSqlQuery query;
    query.prepare("SELECT password FROM usrData WHERE usrName = ?");
    query.addBindValue(usrName);
    if(!query.exec()){
        LOG_ERROR("AllDataDB dont have this usrName!!!");
        //TODO：固定用户名输入

    }
    else{
        while (query.next()) {
            password = query.value(1).toString();
            LOG_INFO(password);
        }
    }
    return password;
}
