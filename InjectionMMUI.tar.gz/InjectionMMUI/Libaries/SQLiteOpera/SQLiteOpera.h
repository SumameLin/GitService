﻿#ifndef __SQLITEOPERA_H
#define __SQLITEOPERA_H

#include <QObject>

class SQLiteOpera : public QObject{
    //发送者和接收者都需要是QObject的子类
    Q_OBJECT

public:
    //explicit是C++的语法关键字。
    //其功能是：其限定的其类的构造函数只能被显式调用
    explicit SQLiteOpera(QObject *parent = nullptr);
    ~SQLiteOpera();

#define SQLiteDBPath "./SQLiteDB/AllData.db"

    QString queryPassword(QString usrName);

};

#endif //__SQLITEOPERA_H
