﻿/******************************************************************************
 * Copyright 2020-2050 INOVANCE Co., Ltd. All right reserved.
 *
 * @file       SetLanguage.cpp
 * @brief
 *
 * @date       2021/07/31
 * @author     linrui
 * @history
 *****************************************************************************/
#include "SetLanguage.h"
#include <Logger.h>

SetLanguage::SetLanguage(QGuiApplication &app,QQmlApplicationEngine &engine)
{
    myApp = &app;
    myEngine = &engine;
}

void SetLanguage::setLanguage(QString language)
{
    QTranslator translator;
    if(language == "US"){
        translator.load(":/en_US.qm");
        LOG_INFO("切换为英文");
    }
    else{
        LOG_INFO("切换为中文");
        translator.load(":/zh_CN.qm");
    }
    myApp->installTranslator(&translator);
    myEngine->retranslate();
}
