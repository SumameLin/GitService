﻿#ifndef __SETLANGUAGE_H
#define __SETLANGUAGE_H

#pragma once
#include <QObject>
#include <QTranslator>
#include <QGuiApplication>
#include <QQmlApplicationEngine>

class SetLanguage : public QObject
{
    Q_OBJECT
public:
    SetLanguage(QGuiApplication &app,QQmlApplicationEngine &engine);
    Q_INVOKABLE void setLanguage(QString language);

private:
    QGuiApplication *myApp;
    QQmlApplicationEngine *myEngine;
};



#endif //__SETLANGUAGE_H
